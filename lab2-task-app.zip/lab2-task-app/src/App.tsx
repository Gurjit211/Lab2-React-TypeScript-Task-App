import { useState } from 'react';
import TaskItem from './TaskItem';
import './App.css';

type Task = {
  id: number;
  task: string;
  completed: boolean;
};

const initialTasks: Task[] = [
  { id: 1, task: "Buy groceries", completed: false },
  { id: 2, task: "Do laundry", completed: true },
  { id: 3, task: "Complete assignment", completed: false },
  { id: 4, task: "Go for a walk", completed: true },
];

function App() {
  const [tasks, setTasks] = useState<Task[]>(initialTasks);
  const [newTask, setNewTask] = useState<string>("");

  const deleteTask = (id: number) => {
    setTasks(tasks.filter(task => task.id !== id));
  };

  const toggleTask = (id: number) => {
    setTasks(tasks.map(task =>
      task.id === id ? { ...task, completed: !task.completed } : task
    ));
  };

  const addTask = () => {
    if (newTask.trim() === "") return;
    const newId = tasks.length > 0 ? Math.max(...tasks.map(t => t.id)) + 1 : 1;
    const taskObj: Task = {
      id: newId,
      task: newTask,
      completed: false,
    };
    setTasks([...tasks, taskObj]);
    setNewTask("");
  };

  return (
    <div className="container">
      <h1>Task List</h1>

      <div className="task-form">
        <input
          type="text"
          value={newTask}
          placeholder="Enter new task"
          onChange={(e) => setNewTask(e.target.value)}
        />
        <button onClick={addTask}>Add Task</button>
      </div>

      {tasks.length === 0 ? (
        <p className="empty">No tasks remaining 🎉</p>
      ) : (
        tasks.map(task => (
          <TaskItem
            key={task.id}
            id={task.id}
            task={task.task}
            completed={task.completed}
            onDelete={deleteTask}
            onToggle={toggleTask}
          />
        ))
      )}
    </div>
  );
}

export default App;
