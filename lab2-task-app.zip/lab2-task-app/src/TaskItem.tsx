type TaskProps = {
  id: number;
  task: string;
  completed: boolean;
  onDelete: (id: number) => void;
  onToggle: (id: number) => void;
};

function TaskItem({ id, task, completed, onDelete, onToggle }: TaskProps) {
  return (
    <div className="task">
      <p className={completed ? "completed" : ""}>
        {task}
      </p>
      <div className="buttons">
        <button onClick={() => onToggle(id)}>
          {completed ? "Undo" : "Complete"}
        </button>
        <button className="delete" onClick={() => onDelete(id)}>
          Delete
        </button>
      </div>
    </div>
  );
}

export default TaskItem;
